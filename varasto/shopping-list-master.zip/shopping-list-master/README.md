

# shopping-list
My solution to the DOM events exercise (lecture 94) - www.udemy.com/the-complete-web-developer-in-2018

See the result [here](https://nickpax.github.io/shopping-list/ )
